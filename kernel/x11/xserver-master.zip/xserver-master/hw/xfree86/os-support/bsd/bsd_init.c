/*
 * Copyright 1992 by Rich Murphey <Rich@Rice.edu>
 * Copyright 1993 by David Wexelblat <dwex@goblin.org>
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the names of Rich Murphey and David Wexelblat
 * not be used in advertising or publicity pertaining to distribution of
 * the software without specific, written prior permission.  Rich Murphey and
 * David Wexelblat make no representations about the suitability of this
 * software for any purpose.  It is provided "as is" without express or
 * implied warranty.
 *
 * RICH MURPHEY AND DAVID WEXELBLAT DISCLAIM ALL WARRANTIES WITH REGARD TO
 * THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS, IN NO EVENT SHALL RICH MURPHEY OR DAVID WEXELBLAT BE LIABLE FOR
 * ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
 * CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */
#include <xorg-config.h>

#include <X11/X.h>
#include <sys/ioctl.h>
#include <stdbool.h>
#include <stdlib.h>
#include <errno.h>

#include "os/cmdline.h"
#include "os/osdep.h"

#include "compiler.h"
#include "xf86.h"
#include "xf86_console_priv.h"
#include "xf86Priv.h"
#include "xf86_os_support.h"
#include "xf86_OSlib.h"
#include "xf86_OSproc.h"
#include "seatd-libseat.h"

#include "xf86_bsd_priv.h"

static Bool KeepTty = FALSE;

#if defined (SYSCONS_SUPPORT) || defined (PCVT_SUPPORT)
int initialVT = -1;
#endif

#ifdef SYSCONS_SUPPORT
/* The FreeBSD 1.1 version syscons driver uses /dev/ttyv0 */
#define SYSCONS_CONSOLE_DEV1 "/dev/ttyv0"
#define SYSCONS_CONSOLE_DEV2 "/dev/vga"
#define SYSCONS_CONSOLE_MODE O_RDWR|O_NDELAY
#endif

#ifdef __GLIBC__
#define setpgrp setpgid
#endif

#define CHECK_DRIVER_MSG \
  "Check your kernel's console driver configuration and /dev entries"

typedef struct console_driver {
    const char *name;
    bool (*open) (void);
} console_driver_t;

/*
 * The sequence of the driver probes is important; start with the
 * driver that is best distinguishable, and end with the most generic
 * driver.  (Otherwise, pcvt would also probe as syscons, and either
 * pcvt or syscons might successfully probe as pccons.)
 */
static console_driver_t console_drivers[] = {
#ifdef SYSCONS_SUPPORT
    {
        .name = "syscons",
        .open = xf86_console_syscons_open,
    },
#endif
#ifdef PCVT_SUPPORT
    {
        .name = "pcvt",
        .open = xf86_console_pcvt_open,
    },
#endif
#ifdef WSCONS_SUPPORT
    {
        .name = "wscons",
        .open = xf86_console_wscons_open,
    },
#endif
};

Bool
xf86VTKeepTtyIsSet(void)
{
     return KeepTty;
}

void xf86_bsd_acquire_vt(void)
{
    if (xf86Info.ShareVTs) {
        close(xf86Info.consoleFd);
        return;
    }

    /*
     * now get the VT
     */
    int result;

    SYSCALL(result = ioctl(xf86Info.consoleFd, VT_ACTIVATE, xf86Info.vtno));
    if (result != 0)
        LogMessageVerb(X_WARNING, 1, "xf86OpenConsole: VT_ACTIVATE failed\n");

    SYSCALL(result = ioctl(xf86Info.consoleFd, VT_WAITACTIVE, xf86Info.vtno));
    if (result != 0)
        LogMessageVerb(X_WARNING, 1, "xf86OpenConsole: VT_WAITACTIVE failed\n");

    OsSignal(SIGUSR1, xf86VTRequest);

    vtmode_t vtmode = {
        .mode   = VT_PROCESS,
        .relsig = SIGUSR1,
        .acqsig = SIGUSR1,
        .frsig  = SIGUSR1
    };

    if (ioctl(xf86Info.consoleFd, VT_SETMODE, &vtmode) < 0)
        FatalError("xf86OpenConsole: VT_SETMODE VT_PROCESS failed");

#if !defined(__OpenBSD__) && !defined(USE_DEV_IO) && !defined(USE_I386_IOPL)
    if (ioctl(xf86Info.consoleFd, KDENABIO, 0) < 0)
        FatalError("xf86OpenConsole: KDENABIO failed (%s)", strerror(errno));
#endif

    if (ioctl(xf86Info.consoleFd, KDSETMODE, KD_GRAPHICS) < 0)
        FatalError("xf86OpenConsole: KDSETMODE KD_GRAPHICS failed");
}

void
xf86OpenConsole(void)
{
    int i;

    if (serverGeneration == 1) {

        /* If libseat is in control, it handles VT switching. */
        if (seatd_libseat_controls_session()) {
            return;
        }

        /* check if we are run with euid==0 */
        if (geteuid() != 0) {
            FatalError("xf86OpenConsole: Server must be suid root");
        }

        if (!KeepTty) {
            /*
             * detaching the controlling tty solves problems of kbd character
             * loss.  This is not interesting for CO driver, because it is
             * exclusive.
             */
            setpgrp(0, getpid());
            if ((i = open("/dev/tty", O_RDWR)) >= 0) {
                ioctl(i, TIOCNOTTY, (char *) 0);
                close(i);
            }
        }

        /* detect which driver we are running on */
        for (unsigned idx=0; idx < ARRAY_SIZE(console_drivers); idx++) {
            if (console_drivers[idx].open())
                break;
        }

        /* Check that a supported console driver was found */
        if (xf86Info.consoleFd < 0) {
            char cons_drivers[80] = { 0, };
            for (i = 0; i < ARRAY_SIZE(console_drivers); i++) {
                if (i) {
                    strcat(cons_drivers, ", ");
                }
                strcat(cons_drivers, console_drivers[i].name);
            }
            FatalError
                ("%s: No console driver found\n\tSupported drivers: %s\n\t%s",
                 "xf86OpenConsole", cons_drivers, CHECK_DRIVER_MSG);
        }
    }
    else {
        /* serverGeneration != 1 */
        if (!xf86Info.ShareVTs && xf86Info.autoVTSwitch
                               && xf86_console_proc_reactivate)
            xf86_console_proc_reactivate();
    }
}

void
xf86CloseConsole(void)
{
    if (xf86Info.ShareVTs)
        return;

    if (xf86_console_proc_close)
        xf86_console_proc_close();
    else
        LogMessageVerb(X_WARNING, 1, "no xf86_console_proc_close() installed\n");
}

int
xf86ProcessArgument(int argc, char *argv[], int i)
{
    /*
     * Keep server from detaching from controlling tty.  This is useful
     * when debugging (so the server can receive keyboard signals.
     */
    if (!strcmp(argv[i], "-keeptty")) {
        KeepTty = TRUE;
        return 1;
    }
#if defined (SYSCONS_SUPPORT) || defined (PCVT_SUPPORT)
    if ((argv[i][0] == 'v') && (argv[i][1] == 't')) {
        int VTnum = -1;
        if (sscanf(argv[i], "vt%2d", &VTnum) == 0 || VTnum < 1 || VTnum > 12) {
            UseMsg();
            return 0;
        }
        xf86_console_requested_vt = VTnum;
        return 1;
    }
#endif                          /* SYSCONS_SUPPORT || PCVT_SUPPORT */
    return 0;
}

void
xf86UseMsg(void)
{
#if defined (SYSCONS_SUPPORT) || defined (PCVT_SUPPORT)
    ErrorF("vtXX                   use the specified VT number (1-12)\n");
#endif                          /* SYSCONS_SUPPORT || PCVT_SUPPORT */
    ErrorF("-keeptty               ");
    ErrorF("don't detach controlling tty (for debugging only)\n");
    return;
}

void
xf86OSInputThreadInit(void)
{
    return;
}
