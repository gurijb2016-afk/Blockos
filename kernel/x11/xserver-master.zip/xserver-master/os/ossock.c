/* SPDX-License-Identifier: X11 OR MIT OR AGPL-3.0-or-later
 *
 * Copyright © 2024 Enrico Weigelt, metux IT consult <info@metux.net>
 */
#include <dix-config.h>

#include <unistd.h>
#include <stdbool.h>

#ifdef WIN32
#include <X11/Xwinsock.h>
#else
#include <sys/ioctl.h>
#endif

#include "os/ossock.h"

void ossock_init(void)
{
#ifdef WIN32
    static WSADATA wsadata;
    if (!wsadata.wVersion)
        WSAStartup(0x0202, &wsadata);
#endif
}

int ossock_ioctl(int fd, unsigned long request, void *arg)
{
#ifdef WIN32
    int ret = ioctlsocket(fd, request, arg);
    if (ret == SOCKET_ERROR)
        ret = WSAGetLastError();
    return ret;
#else
    return ioctl(fd, request,arg);
#endif
}

int ossock_close(int fd)
{
#ifdef WIN32
    int ret = closesocket(fd);
    if (ret == SOCKET_ERROR)
        errno = WSAGetLastError();
    return ret;
#else
    return close(fd);
#endif
}

int ossock_wouldblock(int err)
{
#ifdef WIN32
    return ((err == EAGAIN) || (err == WSAEWOULDBLOCK));
#else
    return ((err == EAGAIN) || (err == EWOULDBLOCK));
#endif
}

bool ossock_eintr(int err)
{
#ifdef WIN32
    return (err == WSAEINTR);
#else
    return (err == EINTR);
#endif
}

int ossock_errno(void)
{
#ifdef WIN32
    return WSAGetLastError();
#else
    return errno;
#endif
}
