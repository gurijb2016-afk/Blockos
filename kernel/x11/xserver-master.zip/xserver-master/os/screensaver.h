/* SPDX-License-Identifier: X11 OR MIT OR AGPL-3.0-or-later
 *
 * Copyright © 2024 Enrico Weigelt, metux IT consult <info@metux.net>
 */
#ifndef _XSERVER_OS_SCREENSAVER_H
#define _XSERVER_OS_SCREENSAVER_H

void SetScreenSaverTimer(void);
void FreeScreenSaverTimer(void);

#endif /* _XSERVER_OS_SCREENSAVER_H */
